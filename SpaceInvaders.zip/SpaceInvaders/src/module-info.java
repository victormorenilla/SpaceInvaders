module SpaceInvaders
{
    requires javafx.graphics;
    requires javafx.media;

    opens videoGame;
}
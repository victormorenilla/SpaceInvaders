package videoGame.Scenes;

import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import videoGame.SpaceInvaders;

import java.nio.file.Files;
import java.nio.file.Paths;

public class CreditScene extends GeneralScene{
    private static final String BACKGROUND_IMAGE="assets/fin.jpg";
    private static final String CALAVERA_IMAGE="assets/calavera1.png";
    private Image background;
    private Image calavera;
    public CreditScene() {
        super();
         try{
            background=new Image(Files.newInputStream(Paths.get(BACKGROUND_IMAGE)));
            calavera=new Image(Files.newInputStream(Paths.get(CALAVERA_IMAGE)));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void showCreditMessage(){
        Font myFont= Font.font("Arial", FontWeight.NORMAL,50);
        gc.setFont(myFont);
        gc.setFill(Color.RED);
        gc.fillText("GAME OVER",175,350);

        myFont=Font.font("Arial",FontWeight.NORMAL,20);
        gc.setFont(myFont);
        gc.setFill(Color.YELLOW);
        gc.fillText("Your Score: "+GameScene.points,250,410);
        gc.setFill(Color.WHITE);
        gc.fillText("PRESS SPACE TO START OVER",160,720);
    }
    @Override
    public void draw() {
        activeKeys.clear();
        new AnimationTimer(){
            public void handle(long CurrentNanoTime) {
                gc.setFill(Color.BLACK);
                gc.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
                gc.drawImage(background,0,0);
                gc.drawImage(calavera,220,70);
                showCreditMessage();

                if (activeKeys.contains(KeyCode.SPACE)) {
                    this.stop();
                    SpaceInvaders.setScene(SpaceInvaders.WELCOME_SCENE);
                }
            }
        }.start();
    }
}


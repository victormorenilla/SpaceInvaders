package videoGame.Scenes;

import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import videoGame.SpaceInvaders;

import java.nio.file.Files;
import java.nio.file.Paths;

public class WelcomeScene extends GeneralScene
    {
        private static final String BACKGROUND_IMAGE="assets/inicio.jpg";
        private static final String NAVE_IMAGE="assets/logo.png";
        private Image background;
        private Image logo;
        public WelcomeScene()
        {
            super(); try{
            background=new Image(Files.newInputStream(Paths.get(BACKGROUND_IMAGE)));
            logo=new Image(Files.newInputStream(Paths.get(NAVE_IMAGE)));
            showWelcomeMessage();
            }catch (Exception e){
            e.printStackTrace();
            }

        }
        private void showWelcomeMessage()
        {
            Font myFont= Font.font("Arial", FontWeight.NORMAL,50);
            gc.setFont(myFont);
            gc.setFill(Color.RED);
            gc.fillText("SPACE ",200,360);
            gc.fillText("INVADERS",160,410);

            myFont=Font.font("Arial",FontWeight.NORMAL,20);
            gc.setFont((myFont));
            gc.setFill(Color.WHITE);
            gc.fillText("PRESS SPACE ",220,475);
            gc.fillText("TO PLAY",250,510);
        }
        @Override
        public void draw()
        {
            activeKeys.clear();
            new AnimationTimer() {
                public void handle(long currentNanoTime) {
                    gc.setFill(Color.BLACK);
                    gc.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
                    gc.drawImage(background,0,0);
                    gc.drawImage(logo,200,100);

                    showWelcomeMessage();

                    if (activeKeys.contains(KeyCode.SPACE)) {
                        this.stop();
                        SpaceInvaders.setScene(SpaceInvaders.GAME_SCENE);
                    } else if (activeKeys.contains(KeyCode.ESCAPE)) {
                        this.stop();
                        SpaceInvaders.exit();
                    }
                }
            }.start();
        }
    }

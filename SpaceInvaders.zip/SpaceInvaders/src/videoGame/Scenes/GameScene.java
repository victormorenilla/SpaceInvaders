package videoGame.Scenes;

import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import videoGame.SpaceInvaders;
import videoGame.Sprites.*;


import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static javafx.scene.input.KeyCode.*;


public class GameScene extends GeneralScene{
    private static final String BACKGROUND_IMAGE="assets/GS1.jpg";
    private static final String BACKGROUND_IMAGE2="assets/pantalla juego.jpg";
    private static final String BACKGROUND_LVL2="assets/espacio.jpg";
    public static final String BACKGROUND_SONG="assets/music.mp3";
    public static final String SOUND_EFFECT="assets/effects.mp3";
    public static final String ATEX="assets/atex.gif";

    List<Shoot > Allshoots= new ArrayList<>();
    List<Shoot > Allshoots2= new ArrayList<>();
    List<Enemy>AllEnemys=new ArrayList<>();
    List<Enemy2>AllEnemys2=new ArrayList<>();
    List<Laser> BossShoot=new ArrayList<>();

    private Image background;
    private Image background2;
    private  Image lvl2;
    private Image atex;
    private MainCharacter spacecraft;
    public Enemy BadSpaceCraft;
    public Enemy2 BadSpace2;
    public Boss boss1=null;
    private Shoot bala;
    private Laser laser;
    private Media effect;
    public static int points=0;
    private int lives=3;
    boolean on=false;
    private int BossLive=300;

    public GameScene() {
        super();
        try{
            background=new Image(Files.newInputStream(Paths.get(BACKGROUND_IMAGE2)));
            background2=new Image(Files.newInputStream(Paths.get(BACKGROUND_IMAGE)));
            lvl2=new Image((Files.newInputStream(Paths.get(BACKGROUND_LVL2))));
            atex=new Image(Files.newInputStream(Paths.get(ATEX)));
            spacecraft =new MainCharacter();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void draw() {
        BossLive=300;
        reset();
        Allshoots.clear();
        sound=new Media(new File(BACKGROUND_SONG).toURI().toString());
        mediaPlayer=new MediaPlayer(sound);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();

        activeKeys.clear();
        spacecraft.moveTo(385,675);

        new AnimationTimer() {
            public void handle(long currentNanoTime) {
                gc.setFill(Color.BLACK);
                gc.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
                Shoot newShoot=null;
                Enemy newEnemy=null;

                if (points < 300) {
                    gc.drawImage(background, 0, 0);
                    spacecraft.draw(gc);

                    //////////////////spacecrafts
                    if (AllEnemys.size() < Enemy.MAX_ENEMY) {
                        BadSpaceCraft = new Enemy();
                        AllEnemys.add(BadSpaceCraft);
                        BadSpaceCraft.moveTo((int) (Math.random() * (GeneralScene.GAME_WIDTH - BadSpaceCraft.ENEMY_WIDTH)) + 1, 0);
                    }
                    for(int i=0;i<AllEnemys.size();i++) {
                        for (int j = 0; j < Allshoots.size(); j++) {
                            if (AllEnemys.get(i).collidesWith(Allshoots.get(j))) {
                                points += 10;
                                //e.increaseDifficulty();
                                playEffect((SOUND_EFFECT));
                                newShoot=Allshoots.get(j);
                                newEnemy=AllEnemys.get(i);
                            } else if (!AllEnemys.get(i).collidesWith(Allshoots.get(j))
                                    && Allshoots.get(j).getY() <= 0) {
                                newShoot=Allshoots.get(j);
                            }
                        }
                    }
                    for (Enemy e:AllEnemys
                         ) {
                        if(e.getY()>=GAME_HEIGHT){
                            newEnemy=e;
                        }
                        if(e.collidesWith(spacecraft))  {
                            lives--;
                            playEffect((SOUND_EFFECT));
                            newEnemy=e;
                            spacecraft.resetPosition();
                        }
                    }
                    Allshoots.remove(newShoot);
                    AllEnemys.remove(newEnemy);
                    ///////////////////shoots
                    if (activeKeys.add(SPACE)) {
                        if(Allshoots.size()<Shoot.MAX_Shoot) {
                            bala = new Shoot();
                            Allshoots.add(bala);
                            bala.moveTo(spacecraft.getX() + 25, spacecraft.getY() - 15);
                        }
                    }
                    for (Shoot s : Allshoots) {
                        s.draw(gc);
                        s.move();
                    }
                    for (Enemy n : AllEnemys) {
                        n.draw(gc);
                        n.move();
                    }
                }
                /////////////////////lvl 2//////////////////////////////////////////////
                else if(points>=300&&points<800){
                    Allshoots.clear();
                    AllEnemys.clear();
                    Enemy2 newEnemy2=null;
                    Shoot newShoot2=null;
                    gc.drawImage(lvl2, 0, 0);
                    spacecraft.draw(gc);

                    //////////////////spacecrafts 2
                    if (AllEnemys2.size() < Enemy2.MAX_ENEMY) {
                        BadSpace2 = new Enemy2();
                        AllEnemys2.add(BadSpace2);
                        BadSpace2.moveTo((int) (Math.random() * (GeneralScene.GAME_WIDTH - BadSpace2.ENEMY_WIDTH)) + 1, 0);
                    }
                    for (Enemy2 z : AllEnemys2) {
                        z.draw(gc);
                        z.move();
                    }
                    for(int x=0;x<AllEnemys2.size();x++) {
                        for (int h = 0; h < Allshoots2.size(); h++) {
                            if (AllEnemys2.get(x).collidesWith(Allshoots2.get(h))) {
                                points += 10;
                                //e.increaseDifficulty();
                                playEffect((SOUND_EFFECT));
                                newShoot2=Allshoots2.get(h);
                                newEnemy2=AllEnemys2.get(x);
                            } else if (!AllEnemys2.get(x).collidesWith(Allshoots2.get(h))
                                    && Allshoots2.get(h).getY() <= 0) {
                                newShoot2 = Allshoots2.get(h);
                            }
                        }
                    }
                    for (Enemy2 w:AllEnemys2
                         ) {
                        if(w.getY()>=GAME_HEIGHT){
                            newEnemy2=w;
                        }
                        if(w.collidesWith(spacecraft))  {
                            lives--;
                            playEffect((SOUND_EFFECT));
                            newEnemy2=w;
                            spacecraft.resetPosition();
                        }
                    }
                    Allshoots2.remove(newShoot2);
                    AllEnemys2.remove(newEnemy2);
                    ///////////////////shoots 2 /////////////
                    if (activeKeys.add(SPACE)) {
                        if(Allshoots2.size()<Shoot.MAX_Shoot) {
                            bala = new Shoot();
                            Allshoots2.add(bala);
                            bala.moveTo(spacecraft.getX() + 25, spacecraft.getY() - 15);
                        }
                    }
                    for (Shoot s : Allshoots2) {
                        s.draw(gc);
                        s.move();
                    }
                }
                /////////////////////////boss//////////////////
                else{
                    Allshoots2.clear();
                    gc.drawImage(background2, 0, 0);
                    spacecraft.draw(gc);
                    if(boss1==null){
                        BossShoot.clear();
                        boss1=new Boss();
                        boss1.moveTo(Boss.BOSS_WIDTH-50,15);

                    }
                    else{
                            boss1.draw(gc);
                            boss1.MoveDown();
                        }
                    if(boss1!=null&&BossShoot.size()<1&&BossLive>0){
                        laser=new Laser();
                        //int n=(int)(Math.random()*((400+1)-200))+200;
                        BossShoot.add(laser);
                        laser.moveTo(boss1.getX()+110, boss1.getY()+150);

                    }
                    for(int y=0;y<BossShoot.size();y++){
                        BossShoot.get(y).draw(gc);
                        BossShoot.get(y).moveLaser();
                        if (BossShoot.get(y).collidesWith(spacecraft) && BossLive > 0) {
                            lives -= 1;
                            playEffect((SOUND_EFFECT));
                            BossShoot.remove(BossShoot.get(y));
                        }
                        else if (BossShoot.get(y).getY() > GAME_HEIGHT) {
                            BossShoot.remove(BossShoot.get(y));
                        }
                    }
                    if(BossLive>=250&&BossLive<=300){
                        boss1.MoveRight();
                    }
                    if(BossLive>=200&&BossLive<250){
                        boss1.MoveLeft();
                    }
                    if(BossLive>=150&&BossLive<200){
                        boss1.MoveRight();
                    }
                    if(BossLive>=100&&BossLive<150){
                        boss1.MoveLeft();
                    }
                    if(BossLive>=50&&BossLive<100){
                        boss1.MoveRight();
                    }
                    if(BossLive>=0&&BossLive<50){
                        boss1.MoveLeft();
                    }

                    if (activeKeys.add(SPACE)) {
                        bala = new Shoot();
                        Allshoots.add(bala);
                        bala.moveTo(spacecraft.getX() + 25, spacecraft.getY() - 15);
                    }
                    for(int x=0;x<Allshoots.size();x++){
                        Allshoots.get(x).draw(gc);
                        Allshoots.get(x).move();
                        if(Allshoots.get(x).collidesWith(boss1)&&BossLive>0){
                            BossLive -= 10;
                            points += 10;
                            playEffect((SOUND_EFFECT));
                            Allshoots.remove(Allshoots.get(x));
                        }
                    }
                    scoreBoss();
                    if(BossLive==0){
                        BossShoot.clear();
                        boss1=null;
                        //BossShoot.clear();
                        gc.drawImage(atex,210,110);
                        Message();
                    }
                }
                updateHUD();
                ///lives<=0
                if ((lives == 0)|| on) {
                    boss1=null;
                    SpaceInvaders.setScene(SpaceInvaders.CREDIT_SCENE);
                    this.stop();
                    mediaPlayer.stop();
                }
                //////scenes
                if (activeKeys.contains(ESCAPE)) {
                    this.stop();
                    SpaceInvaders.setScene(SpaceInvaders.WELCOME_SCENE);
                } else if (activeKeys.contains(ENTER)) {
                    this.stop();
                    SpaceInvaders.setScene(SpaceInvaders.CREDIT_SCENE);
                } else if (activeKeys.contains(LEFT)) spacecraft.move(MainCharacter.LEFT);
                else if (activeKeys.contains(RIGHT)) spacecraft.move(MainCharacter.RIGHT);
            }
        }.start();
    }
    private void playEffect(String path){
        effect=new Media(new File(path).toURI().toString());
        MediaPlayer mediaPlayerEffects = new MediaPlayer(effect);
        mediaPlayerEffects.play();
    }
    private void reset(){
        spacecraft.resetPosition();
        lives=3;
        points=0;
        BadSpaceCraft.STEP_INCREMENT=0f;
    }
    private  void updateHUD(){
        Font myFont= Font.font("Arial", FontWeight.NORMAL,18);
        gc.setFont(myFont);
        gc.setFill(Color.WHITESMOKE);
        gc.fillText("Score: "+points,20,GeneralScene.GAME_HEIGHT-15);
        gc.setFill(Color.YELLOW);
        gc.fillText("Lives: "+lives,GAME_WIDTH-100,GeneralScene.GAME_HEIGHT-15);
    }
    private void scoreBoss(){
        Font myFont= Font.font("Arial", FontWeight.NORMAL,20);
        gc.setFont(myFont);
        gc.setFill(Color.RED);
        gc.fillText("Boss Live: "+BossLive,250,25);
    }
    private void Message(){
        Font myFont= Font.font("Arial", FontWeight.NORMAL,30);
        gc.setFont(myFont);
        gc.setFill(Color.WHITESMOKE);
        gc.fillText("¡CONGRATULATIONS!",GAME_WIDTH-450,GeneralScene.GAME_HEIGHT-400);
        //gc.fillText("kill the boss",GAME_WIDTH-380,GeneralScene.GAME_HEIGHT-360);
        gc.setFill(Color.YELLOW);
        gc.fillText("Press enter to Continue",GAME_WIDTH-440,GeneralScene.GAME_HEIGHT-280);
    }
}

package videoGame.Sprites;

import javafx.scene.image.Image;

import java.nio.file.Files;
import java.nio.file.Paths;


public class Shoot extends Sprite{

    public static final int Shoot_WIDTH=96;
    public static final int Shoot_HEIGHT=96;
    public static int MAX_Shoot=15;

    private static final String IMAGE_PATH="assets/misil.png";

    public Shoot()
    {
        super(Shoot_WIDTH,Shoot_HEIGHT);

        try{
            spriteImage=new Image(Files.newInputStream(Paths.get(IMAGE_PATH)));
            spriteImage=new Image(Files.newInputStream(Paths.get(IMAGE_PATH)));
        }catch(Exception e){
            e.printStackTrace();
        }

    }
    public void move(){
        this.y-=5;
    }
}

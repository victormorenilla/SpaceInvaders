package videoGame.Sprites;

import javafx.scene.image.Image;

import java.nio.file.Files;
import java.nio.file.Paths;

public class Enemy2 extends Sprite{

        private static final  String IMAGE_PATH2="assets/nave2.png";
        public static int MAX_ENEMY=10;
        public static int ENEMY_WIDTH=50;
        public static int ENEMY_HEIGHT=50;
        public static float STEP_INCREMENT=0;

        public Enemy2(){
            super(ENEMY_WIDTH,ENEMY_HEIGHT);
            try
            {
                spriteImage=new Image(Files.newInputStream(Paths.get(IMAGE_PATH2)));
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        public void move(){
            this.y+=(int)(3+STEP_INCREMENT);
        }
        public void increaseDifficulty(){
            STEP_INCREMENT+=0.3F;
        }
}


